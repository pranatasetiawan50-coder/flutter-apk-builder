# City Adventure (Flutter + Flame)

Game open-world 2D top-down mini bergaya GTA klasik (orisinal).

## Cara menjalankan
1. Pasang Flutter SDK (https://flutter.dev).
2. Ekstrak zip, buka terminal di folder `city_adventure`.
3. Buat folder platform: `flutter create .`
4. Ambil dependensi: `flutter pub get`
5. Jalankan: `flutter run` (HP Android/iOS atau emulator)

## Cara bermain
- Joystick kiri bawah: jalan / menyetir.
- Tombol kanan bawah: masuk/keluar mobil (dekati mobil merah dulu).
- Antar ke lingkaran kuning (ikuti panah di layar) untuk +$500.
- Menabrak pejalan kaki = Wanted naik, polisi mengejar. Tertangkap = denda $200.
