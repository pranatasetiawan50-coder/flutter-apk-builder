import 'dart:math';

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

const double cell = 400; // satu blok kota (jalan + gedung)
const int blocks = 10;
const double mapSize = cell * blocks;

class CityGame extends FlameGame {
  final Random rng = Random();
  late final JoystickComponent joystick;
  late final Player player;
  late final Car car;
  late final MissionMarker marker;
  late final TextComponent hud;
  late final TextComponent msg;
  final List<Police> police = [];

  int money = 0;
  int wanted = 0;
  bool inCar = false;
  double wantedTimer = 0;
  double msgTimer = 0;

  @override
  Color backgroundColor() => Colors.black;

  @override
  Future<void> onLoad() async {
    world.add(CityMap());

    car = Car()..position = Vector2(60, 200);
    player = Player()..position = Vector2(60, 60);
    marker = MissionMarker();
    world.addAll([car, player, marker]);
    moveMarker();

    for (var i = 0; i < 40; i++) {
      world.add(Pedestrian(randomRoadSpot()));
    }
    // beberapa mobil parkir/pajangan
    camera.follow(player);

    joystick = JoystickComponent(
      knob: CircleComponent(
          radius: 24, paint: Paint()..color = Colors.white70),
      background: CircleComponent(
          radius: 60, paint: Paint()..color = Colors.white24),
      margin: const EdgeInsets.only(left: 40, bottom: 40),
    );
    final style = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 16,
        fontWeight: FontWeight.bold,
        shadows: [Shadow(blurRadius: 4, color: Colors.black)],
      ),
    );
    hud = TextComponent(position: Vector2(16, 12), textRenderer: style);
    msg = TextComponent(
        position: Vector2(16, 60),
        textRenderer: TextPaint(
          style: const TextStyle(
            color: Colors.amber,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            shadows: [Shadow(blurRadius: 4, color: Colors.black)],
          ),
        ));
    camera.viewport.addAll([joystick, hud, msg]);
    showMessage('Selamat datang! Antar ke penanda kuning untuk uang.');
  }

  // ---------- Util ----------
  Vector2 randomRoadSpot() {
    final i = rng.nextInt(blocks);
    final j = rng.nextInt(blocks);
    return Vector2(i * cell + 10 + rng.nextDouble() * 100,
        j * cell + 10 + rng.nextDouble() * 100);
  }

  bool blocked(Vector2 p, double r) {
    if (p.x < r || p.y < r || p.x > mapSize - r || p.y > mapSize - r) {
      return true;
    }
    final lx = p.x % cell;
    final ly = p.y % cell;
    return lx + r > 140 && lx - r < 380 && ly + r > 140 && ly - r < 380;
  }

  void moveWithCollision(PositionComponent c, Vector2 delta, double r) {
    final nx = c.position + Vector2(delta.x, 0);
    if (!blocked(nx, r)) c.position = nx;
    final ny = c.position + Vector2(0, delta.y);
    if (!blocked(ny, r)) c.position = ny;
  }

  void showMessage(String t) {
    msg.text = t;
    msgTimer = 3;
  }

  void moveMarker() {
    Vector2 p;
    do {
      p = Vector2(rng.nextInt(blocks) * cell + 60.0,
          rng.nextInt(blocks) * cell + 60.0);
    } while (p.distanceTo(player.position) < 800);
    marker.position = p;
  }

  // ---------- Aksi ----------
  void toggleCar() {
    if (inCar) {
      inCar = false;
      for (final o in [
        Vector2(0, 40),
        Vector2(0, -40),
        Vector2(40, 0),
        Vector2(-40, 0)
      ]) {
        final p = car.position + o;
        if (!blocked(p, 9)) {
          player.position = p;
          break;
        }
      }
    } else if (player.position.distanceTo(car.position) < 70) {
      inCar = true;
    } else {
      showMessage('Dekati mobil dulu!');
    }
  }

  void hitPedestrian(Pedestrian p) {
    p.position = randomRoadSpot();
    wanted = min(3, wanted + 1);
    wantedTimer = 15;
    syncPolice();
    showMessage('Kamu menabrak pejalan kaki! Polisi mengejar!');
  }

  void syncPolice() {
    while (police.length < wanted) {
      Vector2 p;
      do {
        p = randomRoadSpot();
      } while (p.distanceTo(player.position) < 500);
      final cop = Police()..position = p;
      police.add(cop);
      world.add(cop);
    }
    while (police.length > wanted) {
      police.removeLast().removeFromParent();
    }
  }

  void busted() {
    money = max(0, money - 200);
    wanted = 0;
    syncPolice();
    inCar = false;
    player.position = Vector2(60, 60);
    car.position = Vector2(60, 200);
    car.velocity.setZero();
    showMessage('BUSTED! Denda \$200');
  }

  @override
  void update(double dt) {
    super.update(dt);

    if (player.position.distanceTo(marker.position) < 45) {
      money += 500;
      showMessage('Misi selesai! +\$500');
      moveMarker();
    }

    if (wanted > 0) {
      wantedTimer -= dt;
      if (wantedTimer <= 0) {
        wanted--;
        wantedTimer = 15;
        syncPolice();
      }
    }

    if (msgTimer > 0) {
      msgTimer -= dt;
      if (msgTimer <= 0) msg.text = '';
    }

    final d = marker.position - player.position;
    const arrows = ['→', '↘', '↓', '↙', '←', '↖', '↑', '↗'];
    final idx = ((atan2(d.y, d.x) / (pi / 4)).round() + 8) % 8;
    hud.text = 'Uang: \$$money   Wanted: ${'★' * wanted}${'☆' * (3 - wanted)}\n'
        'Misi: ${arrows[idx]} ${(d.length / 10).round()} m';
  }
}

// ================= Peta kota =================
class CityMap extends Component with HasGameReference<CityGame> {
  CityMap() : super(priority: -10);

  final _sidewalk = Paint()..color = const Color(0xFFB0B0B0);
  final _road = Paint()..color = const Color(0xFF38383F);
  final _line = Paint()..color = const Color(0xFFFFD54F);
  final _bg = Paint()..color = Colors.black;
  final _roof = Paint();
  final _body = Paint();
  static const palette = [
    Color(0xFF8D6E63),
    Color(0xFF607D8B),
    Color(0xFFA1887F),
    Color(0xFF78909C),
    Color(0xFF7E57C2),
    Color(0xFF5D4037),
  ];

  @override
  void render(Canvas canvas) {
    final v = game.camera.visibleWorldRect;
    canvas.drawRect(v, _bg);
    canvas.drawRect(const Rect.fromLTWH(0, 0, mapSize, mapSize), _sidewalk);

    final c0 = max(0, (v.left / cell).floor());
    final c1 = min(blocks - 1, (v.right / cell).floor());
    final r0 = max(0, (v.top / cell).floor());
    final r1 = min(blocks - 1, (v.bottom / cell).floor());

    // jalan vertikal & horizontal
    for (var i = c0; i <= c1; i++) {
      canvas.drawRect(Rect.fromLTWH(i * cell, 0, 120, mapSize), _road);
    }
    for (var j = r0; j <= r1; j++) {
      canvas.drawRect(Rect.fromLTWH(0, j * cell, mapSize, 120), _road);
    }
    // marka jalan putus-putus
    for (var i = c0; i <= c1; i++) {
      for (var y = (v.top / 40).floor() * 40.0; y < v.bottom; y += 40) {
        if (y < 0 || y > mapSize) continue;
        canvas.drawRect(Rect.fromLTWH(i * cell + 58, y, 4, 20), _line);
      }
    }
    for (var j = r0; j <= r1; j++) {
      for (var x = (v.left / 40).floor() * 40.0; x < v.right; x += 40) {
        if (x < 0 || x > mapSize) continue;
        canvas.drawRect(Rect.fromLTWH(x, j * cell + 58, 20, 4), _line);
      }
    }
    // gedung
    for (var i = c0; i <= c1; i++) {
      for (var j = r0; j <= r1; j++) {
        final col = palette[(i * 7 + j * 13) % palette.length];
        _body.color = col;
        _roof.color = Color.lerp(col, Colors.white, 0.25)!;
        canvas.drawRect(
            Rect.fromLTWH(i * cell + 140, j * cell + 140, 240, 240), _body);
        canvas.drawRect(
            Rect.fromLTWH(i * cell + 160, j * cell + 160, 200, 200), _roof);
      }
    }
  }
}

// ================= Pemain =================
class Player extends PositionComponent with HasGameReference<CityGame> {
  Player()
      : super(size: Vector2.all(20), anchor: Anchor.center, priority: 5);

  final _skin = Paint()..color = const Color(0xFF1E88E5);
  final _head = Paint()..color = Colors.white;

  @override
  void update(double dt) {
    if (game.inCar) {
      position = game.car.position.clone();
      return;
    }
    final d = game.joystick.relativeDelta;
    if (!d.isZero()) game.moveWithCollision(this, d * 170 * dt, 9);
  }

  @override
  void render(Canvas canvas) {
    if (game.inCar) return;
    canvas.drawCircle(const Offset(10, 10), 10, _skin);
    canvas.drawCircle(const Offset(10, 10), 5, _head);
  }
}

// ================= Mobil =================
class Car extends PositionComponent with HasGameReference<CityGame> {
  Car() : super(size: Vector2(56, 30), anchor: Anchor.center, priority: 4);

  final Vector2 velocity = Vector2.zero();
  double get speed => velocity.length;

  final _bodyPaint = Paint()..color = const Color(0xFFD32F2F);
  final _glass = Paint()..color = const Color(0xFF263238);
  final _light = Paint()..color = const Color(0xFFFFF59D);

  @override
  void update(double dt) {
    final t = min(1.0, 4 * dt);
    if (game.inCar) {
      velocity.lerp(game.joystick.relativeDelta * 320, t);
    } else {
      velocity.lerp(Vector2.zero(), t);
    }
    if (velocity.length > 5) {
      game.moveWithCollision(this, velocity * dt, 16);
      angle = atan2(velocity.y, velocity.x);
    }
  }

  @override
  void render(Canvas canvas) {
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            const Rect.fromLTWH(0, 0, 56, 30), const Radius.circular(8)),
        _bodyPaint);
    canvas.drawRect(const Rect.fromLTWH(32, 4, 12, 22), _glass);
    canvas.drawRect(const Rect.fromLTWH(10, 4, 8, 22), _glass);
    canvas.drawRect(const Rect.fromLTWH(52, 3, 4, 7), _light);
    canvas.drawRect(const Rect.fromLTWH(52, 20, 4, 7), _light);
  }
}

// ================= Pejalan kaki =================
class Pedestrian extends PositionComponent with HasGameReference<CityGame> {
  Pedestrian(Vector2 pos)
      : super(
            position: pos,
            size: Vector2.all(16),
            anchor: Anchor.center,
            priority: 3);

  final Vector2 dir = Vector2.zero();
  double timer = 0;
  late final Paint _paint = Paint()
    ..color = Colors.primaries[Random().nextInt(Colors.primaries.length)];

  @override
  void update(double dt) {
    timer -= dt;
    if (timer <= 0) {
      timer = 1 + game.rng.nextDouble() * 3;
      final a = game.rng.nextDouble() * 2 * pi;
      dir.setValues(cos(a), sin(a));
      if (game.rng.nextDouble() < 0.3) dir.setZero();
    }
    game.moveWithCollision(this, dir * 40 * dt, 7);

    if (game.inCar &&
        game.car.speed > 120 &&
        position.distanceTo(game.car.position) < 30) {
      game.hitPedestrian(this);
    }
  }

  @override
  void render(Canvas canvas) {
    canvas.drawCircle(const Offset(8, 8), 7, _paint);
  }
}

// ================= Polisi =================
class Police extends PositionComponent with HasGameReference<CityGame> {
  Police() : super(size: Vector2(52, 28), anchor: Anchor.center, priority: 4);

  double t = 0;
  final _body = Paint()..color = Colors.white;
  final _red = Paint()..color = Colors.red;
  final _blue = Paint()..color = Colors.blue;

  @override
  void update(double dt) {
    t += dt;
    final d = game.player.position - position;
    if (d.length > 1) {
      final speed = 150.0 + game.wanted * 40;
      game.moveWithCollision(this, d.normalized() * speed * dt, 15);
      angle = atan2(d.y, d.x);
    }
    if (d.length < 28) game.busted();
  }

  @override
  void render(Canvas canvas) {
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            const Rect.fromLTWH(0, 0, 52, 28), const Radius.circular(7)),
        _body);
    final flip = (t * 6).floor() % 2 == 0;
    canvas.drawRect(
        const Rect.fromLTWH(22, 2, 8, 11), flip ? _red : _blue);
    canvas.drawRect(
        const Rect.fromLTWH(22, 15, 8, 11), flip ? _blue : _red);
  }
}

// ================= Penanda misi =================
class MissionMarker extends PositionComponent {
  MissionMarker()
      : super(size: Vector2.all(40), anchor: Anchor.center, priority: 1);

  double t = 0;
  final _fill = Paint()..color = const Color(0x88FFEB3B);
  final _ring = Paint()
    ..color = const Color(0xFFFFEB3B)
    ..style = PaintingStyle.stroke
    ..strokeWidth = 4;

  @override
  void update(double dt) => t += dt;

  @override
  void render(Canvas canvas) {
    final r = 16 + 4 * sin(t * 4);
    canvas.drawCircle(const Offset(20, 20), r, _fill);
    canvas.drawCircle(const Offset(20, 20), r, _ring);
  }
}
