import 'package:flame/flame.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import 'city_game.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Flame.device.fullScreen();
  await Flame.device.setLandscape();
  final game = CityGame();
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: GameWidget<CityGame>(
          game: game,
          initialActiveOverlays: const ['controls'],
          overlayBuilderMap: {
            'controls': (context, game) => Align(
                  alignment: Alignment.bottomRight,
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: ElevatedButton.icon(
                      onPressed: game.toggleCar,
                      icon: const Icon(Icons.directions_car),
                      label: const Text('Masuk / Keluar Mobil'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 22, vertical: 18),
                      ),
                    ),
                  ),
                ),
          },
        ),
      ),
    ),
  );
}
